#include <iostream>
#include <vector>

void output(std::vector<std::vector<int>>& s);
void zifan(std::vector<std::vector<int>>& s2);
void duichen(std::vector<std::vector<int>>& s2);
void chuandi(std::vector<std::vector<int>>& s2);
void select();
void exitProgram();

std::vector<std::vector<int>> s(100, std::vector<int>(100, 0));
int z, d, n, i, j;

int main() {
    select();
    return 0;
}

void select() {
    std::cout << "��������������:";
    std::cin >> n;
    std::cout << "��������������:";
    std::cin >> d;
    std::cout << "�������ϵ����:\n";

    for (i = 0; i < n; i++) {
        std::cout << "\n";
        std::cout << "���������ĵ�" << i << "��Ԫ��(Ԫ���Կո�ָ�):";
        for (j = 0; j < d; j++)
            std::cin >> s[i][j];
    }

    std::cout << "�����Ӧ���ѡ���㷨\n1: �Է��հ�\n2: ���ݱհ�\n3: �ԳƱհ�\n4: �˳�\n";
    std::cin >> z;

    switch (z) {
    case 1:
        zifan(s);
        break;
    case 2:
        chuandi(s);
        break;
    case 3:
        duichen(s);
        break;
    case 4:
        exitProgram();
        break;
    }
}

void output(std::vector<std::vector<int>>& s) {
    std::cout << "�����ϵ����Ϊ:\n";
    for (i = 0; i < n; i++) {
        for (j = 0; j < d; j++)
            std::cout << s[i][j];
        std::cout << std::endl;
    }
}

void zifan(std::vector<std::vector<int>>& s2) {
    for (i = 0; i < n; i++)
        s2[i][i] = 1;
    output(s2);
    select();
}

void duichen(std::vector<std::vector<int>>& s2) {
    std::vector<std::vector<int>> s1(100, std::vector<int>(100, 0));

    for (i = 0; i < n; i++)
        for (j = 0; j < d; j++)
            s1[j][i] = s2[i][j];

    for (i = 0; i < n; i++)
        for (j = 0; j < d; j++) {
            s2[i][j] = s2[i][j] + s1[i][j];
            if (s2[i][j] > 1)
                s2[i][j] = 1;
        }
    output(s2);
    select();
}

void chuandi(std::vector<std::vector<int>>& s2) {
    std::vector<std::vector<int>> m(100, std::vector<int>(100, 0));
    std::vector<std::vector<int>> a(100, std::vector<int>(100, 0));
    std::vector<std::vector<int>> t(100, std::vector<int>(100, 0));

    for (i = 0; i < n; i++)
        for (j = 0; j < d; j++) {
            a[i][j] = 0;
            t[i][j] = s2[i][j];
            m[i][j] = s2[i][j];
        }

    for (int h = 0; h < n; h++) {
        for (i = 0; i < n; i++)
            for (j = 0; j < d; j++)
                if (m[i][j] == 1) {
                    for (int k = 0; k < n; k++)
                        if (s2[j][k] == 1)
                            a[i][k] = 1;
                }

        for (i = 0; i < n; i++)
            for (j = 0; j < d; j++) {
                m[i][j] = a[i][j];
                t[i][j] += a[i][j];
                a[i][j] = 0;
                if (t[i][j] > 1)
                    t[i][j] = 1;
            }
    }

    output(t);
    select();
}

void exitProgram() {
    exit(1);
}
